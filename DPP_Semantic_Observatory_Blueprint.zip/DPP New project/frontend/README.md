# Frontend Target Structure

Suggested:

```text
frontend/
  app/
    overview/
    ontology-adoption/
    vocabulary/
    validation/
    drift/
    evidence/
    organisations/
  components/
  lib/
```

The frontend consumes canonical values from the API and does not implement metric formulas.
