# Telemetry Data Model

## `dpp_documents`

- id UUID
- external_identifier
- organisation_id
- domain
- semantic_profile_id
- declared_ontology_version
- document_hash
- ingested_at
- status

## `semantic_observations`

- id UUID
- document_id
- observation_type
- term_iri nullable
- namespace nullable
- category nullable
- ontology_version nullable
- observed_at
- metadata JSONB

## `validation_observations`

- id UUID
- document_id
- severity
- focus_node_hash
- result_path
- source_shape
- constraint_component
- message_code
- observed_at
- metadata JSONB

## `metric_snapshots`

- metric_id
- bucket_start
- bucket_granularity
- dimensions JSONB
- value numeric
- numerator numeric nullable
- denominator numeric nullable
- calculation_version
- calculated_at

## `semantic_incidents`

- id
- detector_type
- severity
- status
- opened_at
- closed_at nullable
- dimensions
- explanation
- detector_version

## `evidence_candidates`

- id
- candidate_type
- status
- label
- first_seen
- last_seen
- occurrence_count
- organisation_count
- domain_count
- metrics JSONB
- recommendation
- created_at
