# Synthetic DPP Ecosystem

## Purpose

A meaningful Observatory requires heterogeneity. Synthetic data provides known ground truth and avoids making unsupported claims about real manufacturers.

## MVP population

Target:
- 10,000–25,000 DPPs
- 20–50 fictional organisations
- electronics + battery domains
- multiple semantic profiles
- 3 ontology versions

## Organisation archetypes

1. `strict_current`
   - current version
   - standard vocabulary
   - high conformance

2. `legacy`
   - old ontology version
   - deprecated terms

3. `customizer`
   - current ontology
   - frequent custom namespace

4. `external_vocab_heavy`
   - legitimate external vocabularies
   - some missing mappings

5. `poor_quality`
   - datatype/cardinality failures

6. `innovator`
   - introduces recurring new concepts

## Fault configuration example

```yaml
unknown_term_rate: 0.02
custom_term_rate: 0.05
deprecated_term_rate: 0.03
datatype_error_rate: 0.04
missing_required_rate: 0.06
legacy_version_share: 0.20
mapping_gap_rate: 0.10
```

## Ground truth

For every injected fault, store:
- document_id;
- fault_type;
- target term/path;
- intended expected detector;
- seed/scenario.

Ground truth must never be mixed into production detector input.
