# Data Governance

## Data minimization

The Observatory is not intended to become a copy of all business data.

Default retained content:
- term IRIs;
- namespace;
- profile/version;
- structural paths;
- validation type;
- organisation/domain identifiers;
- aggregate counts.

Avoid retaining:
- commercially sensitive literal values;
- personal data;
- raw payload duplicates in telemetry.

## Provenance

Every observation traces to:
- source DPP/document;
- ingestion run;
- organisation;
- timestamp;
- semantic profile;
- detector/calculation version.

## Retention

MVP:
- source fixtures retained for reproducibility;
- telemetry retained indefinitely in local development;
- document a future configurable retention policy.
