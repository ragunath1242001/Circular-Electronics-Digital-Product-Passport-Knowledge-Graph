# Testing Strategy

## Unit tests

- term classification;
- version resolution;
- every metric formula;
- detector thresholds;
- mapping coverage;
- evidence aggregation;
- SHACL result normalization.

## Contract tests

- Pydantic event schemas;
- REST response schemas;
- semantic profile package format.

## Integration tests

- Turtle -> parse -> graph -> observations;
- JSON-LD -> parse -> graph -> observations;
- graph -> SHACL -> telemetry;
- telemetry -> metrics;
- incidents -> evidence.

## Synthetic ground-truth tests

For each injected fault class:
- generate controlled documents;
- run detector;
- compare expected vs observed.

## Evaluation

For classification/detection:
- precision;
- recall;
- F1;
- false positives by class.

For deterministic registry checks (unknown/deprecated):
- expected exact detection unless intentionally ambiguous.

## Regression

Freeze representative scenario seeds and expected aggregate snapshots.
