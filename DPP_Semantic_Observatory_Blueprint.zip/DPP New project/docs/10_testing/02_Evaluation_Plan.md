# Evaluation Plan

## E1 — Correctness of semantic signal extraction
Compare extracted signals with expected signals for hand-authored fixtures.

## E2 — Detector accuracy
Use synthetic injected ground truth.

Detector families:
- unknown term;
- deprecated term;
- version drift;
- fragmentation;
- mapping gap.

## E3 — Metric validity
Verify formulas manually on small deterministic datasets.

## E4 — Scalability
Benchmark:
- 1k
- 10k
- 25k DPPs

Capture:
- parsing throughput;
- validation throughput;
- signal event count;
- aggregation time;
- API latency for common dashboard queries.

## E5 — Explainability
For each dashboard metric/incident, verify that a user can trace:
metric -> aggregate counts -> observations -> source documents.

## E6 — Standard-evolution evidence quality
Manual rubric:
- recurrence;
- cross-organisation support;
- semantic coherence;
- actionable recommendation;
- traceability.

Do not claim that an evidence candidate implies a normative standard change.
