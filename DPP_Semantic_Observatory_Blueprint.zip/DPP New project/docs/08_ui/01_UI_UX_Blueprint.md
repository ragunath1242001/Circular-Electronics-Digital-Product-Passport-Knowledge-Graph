# UI/UX Blueprint

## Design language

The application should feel like an observability/engineering product, not a generic admin dashboard.

Key qualities:
- dense but readable;
- drill-down first;
- evidence over decoration;
- trends visible;
- clear distinction between metric, alert and recommendation.

## Pages

### `/overview`
Cards:
- DPPs observed
- organisations
- domains
- current ontology adoption
- SHACL conformance
- vocabulary reuse
- mapping coverage

Charts:
- conformance trend
- current-version adoption trend
- term category distribution

Panels:
- active semantic incidents
- top evidence candidates

### `/ontology-adoption`
- ontology selector
- version distribution
- adoption over time
- lagging organisations
- migration trend

### `/vocabulary`
- standard/external/custom/unknown
- top namespaces
- unknown terms
- custom-term growth

### `/validation`
- failure trend
- top constraints
- affected organisations
- severity filters
- constraint drilldown

### `/drift`
- version incidents
- unknown/deprecated term incidents
- fragmentation groups
- mapping gaps

### `/evidence`
Table/cards:
- candidate type
- label
- organisations
- occurrences
- growth
- status

Evidence detail:
- observation timeline
- term variants
- affected domains
- mappings
- linked incidents
- recommendation
- provenance

### `/organisations/{id}`
- profile/version usage
- conformance
- deviations
- comparison to ecosystem

## UX rule

Every score must have an "Explain" action.
