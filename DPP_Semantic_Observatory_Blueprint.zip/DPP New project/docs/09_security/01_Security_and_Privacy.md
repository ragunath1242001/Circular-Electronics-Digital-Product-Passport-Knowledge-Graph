# Security and Privacy

## Threats

- malicious RDF payloads;
- remote JSON-LD context fetching;
- oversized graph submissions;
- malformed RDF denial of service;
- SPARQL injection where user input is interpolated;
- sensitive literal retention;
- untrusted evidence annotations;
- dependency vulnerabilities.

## MVP controls

1. file size limits;
2. MIME/content checks;
3. safe parser configuration;
4. remote JSON-LD contexts disabled or allow-listed;
5. SPARQL parameterization/query construction discipline;
6. no arbitrary SPARQL update through public API;
7. database least privilege;
8. input validation with Pydantic;
9. structured logs without raw payloads;
10. dependency lockfiles;
11. container non-root where practical;
12. development-only endpoints disabled outside development.

## Privacy

Observability events should preferentially contain semantic structure rather than literal business values.

## Future

- authentication/RBAC;
- tenant isolation;
- signed provenance;
- policy-aware access;
- enterprise secrets management.
