# Non-Functional Requirements

| ID | Requirement |
|---|---|
| NFR-001 | Privacy minimization: collect only semantic/structural values required by each signal |
| NFR-002 | Explainability: every score can be decomposed into source counts and formula |
| NFR-003 | Reproducibility: same seed + configuration yields same synthetic ecosystem |
| NFR-004 | Extensibility: new domains are added through configuration/model packages |
| NFR-005 | Standards independence: core telemetry schema must not hard-code electronics concepts |
| NFR-006 | Reliability: one invalid DPP must not stop batch processing |
| NFR-007 | Idempotency: duplicate ingestion does not duplicate semantic observations |
| NFR-008 | Auditability: evidence must retain lineage to original observations |
| NFR-009 | Performance: MVP target 10,000 DPPs processed locally within an engineering-acceptable batch window |
| NFR-010 | Testability: metric logic has unit tests independent of UI |
| NFR-011 | Portability: Docker Compose is the reference local runtime |
| NFR-012 | Maintainability: bounded contexts use explicit interfaces |
| NFR-013 | Security: external RDF/JSON-LD processing must not permit unsafe remote-context behavior by default |
| NFR-014 | Observability of the Observatory: pipeline errors, processing counts and durations are logged |
| NFR-015 | Determinism: no LLM is required for core scores or MVP detector correctness |
