# User Stories

## US-001 Ontology adoption
As a standards maintainer, I want to see ontology versions used by organisations so that I can identify migration lag.

Acceptance:
- version distribution;
- time trend;
- organisation filter;
- current-version marker;
- trace to source DPP count.

## US-002 Unknown vocabulary
As an ontology engineer, I want to see unknown terms ranked by occurrence and organisation count so that I can distinguish one-off mistakes from ecosystem patterns.

## US-003 SHACL friction
As an ecosystem operator, I want to see recurring SHACL failures over time so that I can determine whether an interoperability problem is growing or shrinking.

## US-004 Fragmentation
As a semantic architect, I want to see alternative representations of configured concepts so that I can quantify semantic fragmentation.

## US-005 Mapping gaps
As a standard maintainer, I want external concepts with no known mapping ranked by usage so that I can prioritize mapping work.

## US-006 Evolution evidence
As a standards maintainer, I want evidence candidates with provenance and recurrence statistics so that I can decide whether a concept or mapping deserves formal review.

## US-007 Organisation diagnostics
As a product-data engineer, I want to compare my organisation with the ecosystem baseline so that I can prioritize remediation.

## US-008 Research evaluation
As a researcher, I want known synthetic ground truth and detector outputs so that I can calculate detector performance.
