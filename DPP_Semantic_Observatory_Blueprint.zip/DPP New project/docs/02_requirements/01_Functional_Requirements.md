# Functional Requirements

Priority: MUST / SHOULD / COULD.

| ID | Requirement | Priority | Acceptance summary |
|---|---|---|---|
| FR-001 | Ingest RDF/Turtle DPP documents | MUST | Valid Turtle is parsed and assigned ingestion provenance |
| FR-002 | Ingest JSON-LD DPP documents | MUST | Valid JSON-LD is normalized to RDF |
| FR-003 | Reject/record malformed semantic documents | MUST | Error event stored without pipeline crash |
| FR-004 | Maintain semantic model registry | MUST | Ontology URI, version, namespaces, terms and status queryable |
| FR-005 | Register SHACL profiles by domain/version | MUST | Correct profile resolved for configured DPP |
| FR-006 | Extract class usage | MUST | rdf:type observations emitted |
| FR-007 | Extract property usage | MUST | Predicate observations emitted |
| FR-008 | Extract namespace usage | MUST | Namespace counts emitted |
| FR-009 | Detect ontology/model version | MUST | Observed or inferred version recorded with method |
| FR-010 | Classify standard/external/custom terms | MUST | Every observed semantic term has category |
| FR-011 | Execute SHACL validation | MUST | Results stored as normalized telemetry |
| FR-012 | Persist validation severity/path/constraint | MUST | Diagnostic details retained |
| FR-013 | Detect unknown terms | MUST | Terms not in configured registry are flagged |
| FR-014 | Detect deprecated terms | MUST | Deprecated concepts produce events |
| FR-015 | Calculate ontology adoption | MUST | Filterable by time/domain/org |
| FR-016 | Calculate vocabulary reuse | MUST | Formula documented and reproducible |
| FR-017 | Calculate SHACL conformance | MUST | DPP and constraint-level variants supported |
| FR-018 | Calculate version consistency/drift | MUST | Current and historical distributions available |
| FR-019 | Calculate custom-term ratio | MUST | Standard/external/custom denominator documented |
| FR-020 | Maintain mapping registry | MUST | Source, target, relation, provenance queryable |
| FR-021 | Calculate mapping coverage | MUST | Mapped/unmapped external concepts observable |
| FR-022 | Detect configured semantic fragmentation | MUST | Equivalent concept groups can be registered and measured |
| FR-023 | Maintain time-series aggregates | MUST | Metrics available by daily bucket |
| FR-024 | Generate semantic incidents | MUST | Threshold breaches create explainable incidents |
| FR-025 | Aggregate evidence candidates | MUST | Repeated related observations become reviewable evidence |
| FR-026 | Show evidence provenance | MUST | Every evidence card traces to observations |
| FR-027 | Provide ecosystem dashboard | MUST | Main KPIs, trends and active incidents visible |
| FR-028 | Provide ontology adoption view | MUST | Version distributions and trends visible |
| FR-029 | Provide drift view | MUST | Unknown/deprecated/custom terms visible |
| FR-030 | Provide validation intelligence view | MUST | Top failing constraints and trends visible |
| FR-031 | Provide standard-evolution evidence view | MUST | Candidate concepts/mappings ranked by evidence |
| FR-032 | Expose REST API | MUST | OpenAPI generated |
| FR-033 | Expose deep semantic query via SPARQL | SHOULD | KG remains directly queryable |
| FR-034 | Export evidence report as JSON | SHOULD | Machine-readable evidence available |
| FR-035 | Support synthetic scenario generation | MUST | Seeded repeatable scenario generation |
| FR-036 | Inject controlled semantic faults | MUST | Fault classes can be configured |
| FR-037 | Evaluate detectors against ground truth | MUST | Precision/recall computed where applicable |
| FR-038 | Optional AI explanation layer | COULD | AI consumes evidence; never fabricates metric values |
| FR-039 | Cross-sector comparison | SHOULD | Electronics vs batteries initially supported |
| FR-040 | Configurable metric thresholds | SHOULD | Threshold changes do not require code changes |

## Rules

- No metric may exist only in UI code.
- Every metric must have a named specification.
- Every detector must emit structured evidence.
- Every event must include provenance and timestamp.
- Every AI-generated explanation must point to deterministic evidence.
