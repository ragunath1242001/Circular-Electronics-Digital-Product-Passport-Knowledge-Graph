# MVP Acceptance Criteria

## AC-001 Dataset
- >= 10,000 generated DPPs
- >= 20 fictional organisations
- electronics + battery domains
- >= 3 ontology versions represented
- reproducible random seed

## AC-002 Fault injection
Dataset includes known:
- unknown terms;
- deprecated terms;
- missing required properties;
- datatype violations;
- custom namespaces;
- old ontology versions;
- configured semantic variants;
- unmapped external concepts.

## AC-003 Processing
- batch ingestion completes without stopping on individual invalid records;
- duplicate document ingestion is idempotent;
- failed documents retain error telemetry.

## AC-004 Metrics
Each MVP metric has:
- formula;
- numerator/denominator;
- filters;
- edge-case handling;
- unit tests;
- API output;
- UI visualization.

## AC-005 Evidence
Every evidence candidate displays:
- candidate type;
- affected concept(s);
- occurrence count;
- organisation count;
- first/last seen;
- trend;
- linked observations;
- recommendation phrased as human review, not automatic standard change.

## AC-006 Evaluation
Unknown/deprecated detection should be exact against registry ground truth.
Fragmentation detection must be evaluated against configured equivalence groups.
No performance claim may appear without evaluation output.

## AC-007 Deployment
A new developer can run the MVP using documented Docker Compose commands after configuration.
