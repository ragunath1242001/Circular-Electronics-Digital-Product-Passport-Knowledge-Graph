# System Architecture

## Logical components

### 1. Ingestion Gateway
Responsibilities:
- receive files/API submissions;
- assign source metadata;
- calculate document hash;
- enforce size/type constraints;
- enqueue processing.

### 2. Semantic Parser & Normalizer
Responsibilities:
- parse RDF/Turtle;
- parse JSON-LD;
- normalize RDF representation;
- prohibit unsafe remote-context behavior unless allow-listed;
- capture parse errors.

### 3. Semantic Model Registry
Responsibilities:
- ontology/version catalogue;
- known namespace/term index;
- deprecated term list;
- domain profiles;
- SHACL shape registration;
- mapping registry.

### 4. SHACL Validator
Responsibilities:
- resolve validation profile;
- run pySHACL;
- normalize results to telemetry events.

### 5. Signal Collector
Responsibilities:
- class usage;
- property usage;
- namespace usage;
- ontology/version signal;
- vocabulary category;
- mapping usage.

### 6. Telemetry Store
PostgreSQL is authoritative for:
- ingestion records;
- observation events;
- validation events;
- metric snapshots;
- incidents;
- evidence candidates.

### 7. Knowledge Graph
Apache Jena Fuseki is authoritative for:
- normalized DPP RDF;
- ontology metadata where useful;
- semantic exploration/SPARQL.

### 8. Metrics Engine
Pure functions/services calculating documented KPIs.

### 9. Drift Engine
Detects:
- unknown terms;
- deprecated terms;
- version drift;
- custom vocabulary growth;
- fragmentation patterns;
- mapping gaps.

### 10. Evidence Engine
Aggregates repeated patterns into reviewable evidence.

### 11. API
FastAPI endpoints for dashboards, drilldowns and evidence.

### 12. Frontend
React/Next.js observability dashboard.

## Data flow

```text
DPP file/API
 -> ingestion record
 -> parse/normalize
 -> graph persistence
 -> SHACL validation
 -> signal extraction
 -> telemetry events
 -> aggregation
 -> metrics/drift/evidence
 -> API
 -> dashboard
```

## Architectural rule

The dashboard never computes canonical metrics itself.
