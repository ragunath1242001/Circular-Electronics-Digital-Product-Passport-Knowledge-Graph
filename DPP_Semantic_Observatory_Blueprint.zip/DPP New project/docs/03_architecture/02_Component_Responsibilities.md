# Component Responsibilities and Interfaces

## `semantic_registry`
Input:
- ontology package metadata
- SHACL files
- mapping files

Output:
- `SemanticProfile`
- `TermClassification`
- `VersionStatus`
- `MappingResolution`

## `ingestion`
Input:
- document bytes
- source metadata

Output:
- `IngestionRecord`
- normalized graph or parse failure

## `validation`
Input:
- RDF graph
- semantic profile

Output:
- `ValidationObservation[]`

## `collectors`
Input:
- normalized graph
- semantic profile

Output:
- `SemanticObservation[]`

## `metrics`
Input:
- observations + query window

Output:
- typed metric result containing:
  - value
  - numerator
  - denominator
  - filters
  - calculation timestamp

## `detectors`
Input:
- observations, registry, history

Output:
- `SemanticIncident[]`

## `evidence`
Input:
- incidents + observations

Output:
- `EvidenceCandidate[]`

## Prohibited coupling

- frontend -> database direct access
- metric -> UI-specific logic
- detector -> LLM dependency
- ingestion -> hard-coded electronics ontology
- evidence engine -> automatic ontology modification
