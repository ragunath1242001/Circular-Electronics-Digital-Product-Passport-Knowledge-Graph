# Event Architecture

## Canonical event envelope

```json
{
  "event_id": "uuid",
  "event_type": "TERM_USAGE",
  "occurred_at": "ISO-8601",
  "ingestion_id": "uuid",
  "document_id": "uuid",
  "organisation_id": "org-01",
  "domain": "electronics",
  "semantic_profile_id": "profile-id",
  "payload": {}
}
```

## MVP event types

- DOCUMENT_INGESTED
- DOCUMENT_PARSE_FAILED
- ONTOLOGY_VERSION_OBSERVED
- CLASS_USAGE
- PROPERTY_USAGE
- NAMESPACE_USAGE
- UNKNOWN_TERM
- DEPRECATED_TERM
- CUSTOM_TERM
- EXTERNAL_TERM
- SHACL_VIOLATION
- SHACL_WARNING
- MAPPING_USED
- MAPPING_MISSING

## Event design rule

Events are immutable observations. Corrections create new state/evidence records rather than rewriting historical observations.
