# Data Storage Architecture

## PostgreSQL

Tables/groups:
- organisations
- domains
- dpp_documents
- ingestion_runs
- semantic_observations
- validation_observations
- mappings
- metric_snapshots
- semantic_incidents
- evidence_candidates
- evidence_observation_links

Use PostgreSQL for high-volume operational/time-aware queries.

## Apache Jena Fuseki

Named graph strategy:

```text
urn:dpp:{document-id}
urn:ontology:{ontology-id}:{version}
urn:mappings:{mapping-set-id}
```

Use Fuseki for:
- semantic exploration;
- graph relations;
- SPARQL;
- RDF-native model interrogation.

## Rule

Do not duplicate every relational aggregate into RDF.

RDF stores semantic knowledge.
PostgreSQL stores operational telemetry.
Evidence may reference both.
