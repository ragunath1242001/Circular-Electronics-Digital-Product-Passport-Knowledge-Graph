# REST API Specification

Prefix: `/api/v1`

## Ingestion

`POST /dpps`
- upload RDF/Turtle or JSON-LD

`GET /dpps/{id}`
- ingestion + semantic summary

## Ecosystem

`GET /ecosystem/summary`
- document count
- organisation count
- domains
- ontology/version distribution
- main metrics

## Metrics

`GET /metrics`
Parameters:
- metric_id
- from
- to
- organisation
- domain
- granularity

`GET /metrics/{metric_id}/explain`
Returns formula + numerator/denominator + calculation version.

## Terms

`GET /terms/unknown`
`GET /terms/deprecated`
`GET /terms/custom`
`GET /terms/{encoded_iri}`

## Validation

`GET /validation/summary`
`GET /validation/constraints`
`GET /validation/constraints/{id}`

## Versions

`GET /ontologies`
`GET /ontologies/{id}/versions`
`GET /ontologies/{id}/adoption`

## Mappings

`GET /mappings`
`GET /mappings/gaps`

## Incidents

`GET /incidents`
`GET /incidents/{id}`

## Evidence

`GET /evidence`
`GET /evidence/{id}`
`PATCH /evidence/{id}` for human status/annotation

## Synthetic data

Development-only:
`POST /dev/scenarios/generate`
`GET /dev/scenarios/{id}/ground-truth`

## API requirements

- pagination;
- stable schemas;
- OpenAPI;
- typed Pydantic models;
- filter validation;
- no raw SQL exposed.
