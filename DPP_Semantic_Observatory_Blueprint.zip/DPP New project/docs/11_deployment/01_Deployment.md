# Deployment Blueprint

## Docker Compose services

```text
postgres
fuseki
backend
frontend
```

Optional:
```text
worker
```

## Environment

`.env.example` should define:
- database URL;
- Fuseki URL;
- environment;
- upload size;
- allow-listed JSON-LD context domains;
- synthetic seed;
- feature flags.

## Local development

Goal:
```bash
docker compose up --build
```

Then:
- API: `http://localhost:8000`
- OpenAPI: `http://localhost:8000/docs`
- Frontend: `http://localhost:3000`
- Fuseki: internal/admin endpoint as documented

## CI

Pipeline:
1. lint
2. type check
3. unit tests
4. integration tests
5. build containers
6. synthetic smoke scenario
