# Mapping Model

## Supported relations

For MVP:
- `skos:exactMatch`
- `skos:closeMatch`
- `skos:broadMatch`
- `skos:narrowMatch`
- `owl:equivalentProperty`
- `owl:equivalentClass`

## Mapping record

Fields:
- mapping_id
- source_iri
- target_iri
- relation
- mapping_set/version
- confidence (only if algorithmic)
- status: proposed/approved/deprecated
- provenance
- created_at

## Important distinction

A missing mapping is not automatically an error.

It becomes observability evidence when:
- external/custom term usage is significant;
- semantic equivalence is configured or strongly supported;
- no approved mapping exists.
