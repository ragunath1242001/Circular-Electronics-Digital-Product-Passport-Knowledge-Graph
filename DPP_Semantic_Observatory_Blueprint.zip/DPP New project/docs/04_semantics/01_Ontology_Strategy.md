# Ontology Strategy

## MVP semantic packages

1. DPP core subset
2. Electronics application profile
3. Battery application profile
4. Supporting vocabularies:
   - PROV-O for provenance
   - SKOS for mapping relationships
   - QUDT for units
   - DCTERMS where appropriate

## Modeling principle

Do not invent a large ontology merely for visual impact.

Only model terms required by:
- synthetic scenarios;
- observability experiments;
- validation;
- mappings.

## Versioning

Create at least three synthetic/model snapshots:
- v1.0
- v1.1
- v2.0 current

Introduce deliberate changes:
- one deprecated property;
- one renamed/mapped property;
- one new required property;
- one changed cardinality;
- one new class/property used in battery profile.

This makes version-drift experiments meaningful.

## Application profiles

Each profile declares:
- required ontology version(s);
- accepted external vocabularies;
- SHACL shapes;
- known mappings;
- current/deprecated terms.
