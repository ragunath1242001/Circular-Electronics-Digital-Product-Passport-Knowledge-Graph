# SHACL Validation Design

## Validation categories

- identity
- manufacturer/economic operator
- material composition
- battery characteristics
- circularity/repair
- datatype/unit
- provenance
- vocabulary usage where expressible

## Telemetry requirement

A validation result must capture:
- focus node;
- result path;
- constraint component;
- source shape;
- severity;
- message;
- value where safe/necessary;
- semantic profile;
- ontology version;
- organisation/domain;
- timestamp.

## Do not store sensitive values unnecessarily

For observability, most metrics need:
- path,
- constraint,
- severity,
- counts,

not full payload values.

## Output

Validation produces normalized observations, not just a report blob.
