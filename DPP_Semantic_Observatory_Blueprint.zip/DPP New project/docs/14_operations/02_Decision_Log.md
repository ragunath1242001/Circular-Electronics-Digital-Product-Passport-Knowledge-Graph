# Architecture Decision Log

Use this file as an index. Add individual ADRs under `docs/14_operations/adr/`.

## ADR-001 Hybrid persistence
Decision: RDF/Fuseki for semantic knowledge; PostgreSQL for operational telemetry and aggregates.

## ADR-002 No composite interoperability score in MVP
Decision: publish component metrics first.

## ADR-003 Deterministic core
Decision: no LLM dependency for core metrics/detectors.

## ADR-004 Synthetic ground truth
Decision: evaluation begins on fictional organizations and injected faults.

## ADR-005 Human-in-the-loop standard evolution
Decision: evidence only; no automatic ontology changes.
