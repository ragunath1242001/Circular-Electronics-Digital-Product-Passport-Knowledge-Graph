# Observability of the Observatory

The platform itself must expose operational health.

## Logs

Structured fields:
- correlation_id
- ingestion_id
- document_id
- component
- duration_ms
- status
- error_code

Do not log raw DPP payloads by default.

## Internal metrics

- documents_received_total
- documents_parsed_total
- documents_failed_total
- shacl_validations_total
- shacl_validation_duration
- observations_emitted_total
- metric_calculation_duration
- detector_runs_total
- evidence_candidates_total

## Health endpoints

- `/health/live`
- `/health/ready`

Readiness checks:
- PostgreSQL
- Fuseki
- model registry load
