# Research Questions

## RQ1
Which observable semantic signals can characterize interoperability in heterogeneous DPP ecosystems?

## RQ2
How can ontology-version drift, vocabulary fragmentation and mapping gaps be detected from DPP implementation usage?

## RQ3
How can these observations be transformed into explainable semantic-interoperability metrics?

## RQ4
Can aggregated semantic-usage evidence reveal recurring implementation needs that merit review during evolution of shared DPP semantic models?

## Research contribution boundary

The project does not claim:
- a universal semantic interoperability metric;
- proof that a recurring custom term must enter a standard;
- production findings about real manufacturers unless real, authorized data is later used.

The contribution is a framework/prototype for **observable semantic evidence** and evaluation on controlled ecosystems.
