# Experimental Design

## Independent variables

- ontology version diversity;
- custom vocabulary rate;
- deprecated term rate;
- mapping coverage;
- validation error rate;
- number of organisations;
- number of domains.

## Dependent variables

- detector precision/recall;
- metric response;
- incident detection delay;
- evidence recurrence statistics;
- processing throughput.

## Experiments

### EXP-01 Version fragmentation
Increase legacy-version share from 0% to 50%.
Expected: adoption and version distribution respond monotonically.

### EXP-02 Vocabulary fragmentation
Introduce 1–5 representations for configured concept groups.
Expected: fragmentation index rises.

### EXP-03 Mapping gap
Increase external term usage with/without approved mappings.
Expected: mapping coverage responds correctly.

### EXP-04 Validation friction
Inject repeated failures on selected SHACL constraints.
Expected: constraint-level trend highlights targeted rule.

### EXP-05 Emerging concept
Introduce semantically grouped custom terms across increasing organisation counts.
Expected: evidence candidate strengthens based on recurrence dimensions.
