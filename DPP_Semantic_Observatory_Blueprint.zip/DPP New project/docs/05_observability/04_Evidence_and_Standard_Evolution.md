# Evidence for Standard Evolution

## Goal

Convert repeated operational observations into **human-reviewable evidence**, not automatic ontology changes.

## Evidence candidate types

- EMERGING_CONCEPT
- MAPPING_NEEDED
- DOCUMENTATION_FRICTION
- DEPRECATION_MIGRATION_PROBLEM
- SHACL_RULE_FRICTION
- CROSS_SECTOR_MODEL_CONFLICT
- VERSION_MIGRATION_FRICTION

## Candidate scoring dimensions

Do not create one opaque score initially. Retain dimensions:
- occurrence_count;
- organisation_count;
- domain_count;
- growth_rate;
- persistence_days;
- mapping_status;
- conformance impact;
- confidence of semantic clustering.

## Example

```text
Candidate: EMERGING_CONCEPT
Canonical label: Battery Health

Observed variants:
- vendorA:batteryHealth
- vendorB:healthScore
- vendorC:batteryCondition

Documents: 1,482
Organisations: 19
First seen: ...
Last seen: ...
30d growth: +42%
Approved mapping: none

Recommendation:
Review whether the shared model needs a concept, mapping,
or clearer reuse guidance.
```

## Human governance boundary

Actions supported:
- inspect;
- annotate;
- dismiss;
- mark for review;
- export.

Actions prohibited in MVP:
- modify ontology automatically;
- publish a new standard version;
- approve mapping automatically.
