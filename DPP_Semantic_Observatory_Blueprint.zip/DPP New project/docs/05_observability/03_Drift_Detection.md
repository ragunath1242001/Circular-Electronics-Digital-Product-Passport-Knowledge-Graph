# Semantic Drift Detection

## DET-001 Unknown term detector
Rule-based against semantic registry.

## DET-002 Deprecated term detector
Rule-based against versioned registry.

## DET-003 Version drift detector
Triggers when:
- legacy version share exceeds configured threshold; or
- legacy share increases for N periods.

## DET-004 Custom vocabulary growth detector
Detects statistically/materially relevant increase in custom-term share over a configured rolling window.

MVP can use deterministic thresholding. Advanced anomaly detection is Phase II.

## DET-005 Fragmentation detector
Uses configured equivalence/variant groups.

Example group:

```yaml
concept: BatteryCapacity
representations:
  - dpp:batteryCapacity
  - batt:ratedCapacity
  - vendor:battery_capacity
```

## DET-006 Mapping gap detector
Ranks frequently observed concepts classified as mappable but without approved mapping.

## Detector output contract

Every detector returns:
- incident type;
- severity;
- affected entities;
- observed values;
- baseline/comparison;
- threshold/rule;
- evidence references;
- explanation template.
