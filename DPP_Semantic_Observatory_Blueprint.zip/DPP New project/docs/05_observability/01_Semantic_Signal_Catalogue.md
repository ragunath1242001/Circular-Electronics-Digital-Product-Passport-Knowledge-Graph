# Semantic Signal Catalogue

Each signal is a raw observable fact. Metrics are derived from signals.

| Signal ID | Signal | Example |
|---|---|---|
| SIG-001 | Ontology URI observed | `https://example/dpp/core` |
| SIG-002 | Ontology version observed | `2.0` |
| SIG-003 | RDF class used | `dpp:Product` |
| SIG-004 | RDF property used | `dpp:manufacturer` |
| SIG-005 | Namespace used | `https://vendor.example/ns#` |
| SIG-006 | Standard term used | registered DPP term |
| SIG-007 | External approved term used | QUDT / PROV etc. |
| SIG-008 | Custom term used | vendor namespace |
| SIG-009 | Unknown term used | not classifiable |
| SIG-010 | Deprecated term used | old property |
| SIG-011 | SHACL violation | minCount failure |
| SIG-012 | SHACL warning | recommended field missing |
| SIG-013 | Mapping used | external -> core |
| SIG-014 | Mapping missing | recurring external term unmapped |
| SIG-015 | Semantic variant used | alternative term in configured concept group |
| SIG-016 | Datatype mismatch | string instead of decimal |
| SIG-017 | Unit mismatch | expected QUDT unit family |
| SIG-018 | Profile mismatch | document declares wrong/incompatible profile |
| SIG-019 | Parse failure | malformed input |
| SIG-020 | Identifier anomaly | missing/duplicate identifier where detectable |

## Mandatory dimensions

Every signal should include when applicable:
- time;
- organisation;
- domain;
- document;
- semantic profile;
- ontology version;
- term/path;
- source/provenance.

## Privacy classification

Each signal declares whether it contains:
- no payload value;
- normalized category;
- potentially sensitive value.

Default: do not retain payload values.
