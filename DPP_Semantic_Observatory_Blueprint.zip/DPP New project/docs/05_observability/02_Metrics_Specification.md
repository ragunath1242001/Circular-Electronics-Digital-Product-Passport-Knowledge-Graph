# Metrics Specification

No metric may be displayed without a documented formula and edge-case behavior.

## MET-001 Current Ontology Adoption Rate

Purpose: measure adoption of the designated current ontology version.

Formula:

```text
DPPs observed with current ontology version
-------------------------------------------
DPPs for which ontology version is resolvable
```

Dimensions:
- organisation
- domain
- day/week/month

Edge case:
- unresolved versions are reported separately, not silently included as non-adoption.

## MET-002 Vocabulary Reuse Rate

MVP definition:

```text
standard + approved external term usages
----------------------------------------
all classified semantic term usages
```

Custom/unknown usage is excluded from numerator.

Report the components separately to avoid hiding behavior.

## MET-003 Custom Term Ratio

```text
custom term usages
------------------
all classified semantic term usages
```

## MET-004 Unknown Term Ratio

```text
unknown term usages
-------------------
all semantic term usages inspected
```

## MET-005 DPP SHACL Conformance Rate

```text
DPPs with zero SHACL Violations
-------------------------------
DPPs validated
```

Warnings do not fail this metric but are displayed separately.

## MET-006 Constraint Conformance Rate

Per shape/constraint:

```text
validations without violation for constraint
--------------------------------------------
validations in which constraint was evaluated
```

## MET-007 Version Consistency

MVP implementation:
- calculate share of documents on the modal/current version;
- report full distribution;
- do not pretend one scalar fully describes version diversity.

## MET-008 Mapping Coverage

```text
distinct observed external/custom concepts with approved mapping
---------------------------------------------------------------
distinct observed external/custom concepts considered mappable
```

The denominator requires an explicit classification rule.

## MET-009 Semantic Fragmentation Index

For configured concept group C:

```text
1 - (usage of dominant representation / all usages of representations in C)
```

Interpretation:
- 0.0 => single representation;
- larger => more fragmented.

Always show representation distribution alongside scalar.

## MET-010 Deprecated Usage Rate

```text
deprecated term usages
----------------------
all registered-model term usages
```

## Composite score policy

A single "Interoperability Health" score is **not part of the first MVP release**.

Only introduce it after:
- component metrics are validated;
- weights have a documented rationale;
- sensitivity analysis is performed.
