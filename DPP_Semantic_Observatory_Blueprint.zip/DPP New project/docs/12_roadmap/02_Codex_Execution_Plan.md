# Codex Execution Plan

## Operating rule

Codex should implement one vertical slice at a time and must not fabricate missing standards or metric definitions.

## Prompt 1 — Foundation

Create:
- backend FastAPI project;
- frontend Next.js project;
- Docker Compose;
- PostgreSQL;
- Fuseki;
- health endpoints;
- test framework.

Do not implement observability logic yet.

## Prompt 2 — Semantic registry

Implement domain-neutral registry types:
- OntologyDefinition
- OntologyVersion
- SemanticProfile
- TermDefinition
- MappingDefinition

Load definitions from version-controlled YAML/JSON metadata plus RDF/SHACL files.

## Prompt 3 — Synthetic generator

Implement deterministic generator with:
- organisation archetypes;
- scenario config;
- fault injection;
- ground truth output.

## Prompt 4 — Ingestion

Implement:
- Turtle;
- JSON-LD;
- hashing/idempotency;
- RDF normalization;
- safe JSON-LD context policy;
- Fuseki persistence.

## Prompt 5 — Validation

Implement pySHACL adapter and normalized validation event model.

## Prompt 6 — Signals

Implement signal collectors as independent pure/testable components.

## Prompt 7 — Metrics

Implement only metrics documented in `docs/05_observability/02_Metrics_Specification.md`.

Do not add a composite interoperability score.

## Prompt 8 — Detectors

Implement deterministic detectors and incident model.

## Prompt 9 — Evidence

Implement evidence aggregation and provenance links.

## Prompt 10 — UI

Build dashboard against APIs. UI must not calculate canonical metrics.

## Prompt 11 — Evaluation

Generate deterministic scenarios and evaluation report.

## Quality gates after every prompt

- tests pass;
- type checks pass;
- docs updated;
- no duplicate business logic;
- new DB migrations included;
- no secrets committed.
