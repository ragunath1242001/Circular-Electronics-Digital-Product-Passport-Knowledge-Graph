# Implementation Roadmap

## Phase 0 — Repository foundation
Deliverables:
- project structure;
- Docker Compose;
- backend/frontend skeleton;
- PostgreSQL/Fuseki connectivity;
- CI;
- config strategy.

Exit:
- all services boot.

## Phase 1 — Semantic registry
Deliverables:
- ontology package format;
- versions;
- term index;
- deprecated terms;
- SHACL profile registry;
- mapping registry.

Exit:
- API/query can resolve a term and version status.

## Phase 2 — Synthetic ecosystem
Deliverables:
- organisation archetypes;
- seed-based generator;
- electronics/battery DPP generator;
- controlled fault injection;
- ground truth.

Exit:
- >=10k repeatable DPPs.

## Phase 3 — Ingestion + KG
Deliverables:
- Turtle/JSON-LD ingest;
- normalization;
- document hash/idempotency;
- Fuseki named graph persistence;
- parse failure telemetry.

## Phase 4 — SHACL telemetry
Deliverables:
- profile resolution;
- pySHACL;
- normalized violation events;
- validation summary API.

## Phase 5 — Signal collectors
Deliverables:
- class/property/namespace;
- version;
- term classification;
- mapping observations.

## Phase 6 — Metrics engine
Implement:
- adoption;
- vocabulary reuse;
- custom/unknown;
- conformance;
- version distribution;
- deprecated usage;
- mapping coverage;
- configured fragmentation.

Every metric gets tests + explain endpoint.

## Phase 7 — Drift detectors
Implement deterministic detectors first.

## Phase 8 — Evidence engine
Implement:
- grouping;
- recurrence;
- cross-org counts;
- trend;
- human status workflow.

## Phase 9 — API
Finalize dashboard-oriented endpoints.

## Phase 10 — Dashboard
Build pages in this order:
1. overview
2. ontology adoption
3. validation
4. vocabulary/drift
5. evidence
6. organisation detail

## Phase 11 — Evaluation
Run benchmark and ground-truth evaluation.

## Phase 12 — Phase II
Candidates:
- automated lexical/embedding clustering;
- LLM-assisted evidence explanation;
- cross-sector semantic alignment;
- Treehouse/Vocabulary Hub integration adapter;
- richer DPP sources;
- standard evolution workflow export.
