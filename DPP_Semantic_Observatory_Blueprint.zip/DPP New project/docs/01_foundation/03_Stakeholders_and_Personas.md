# Stakeholders and Personas

## P1 — Semantic Standard Maintainer
Needs to know how specifications are used in implementations.

Key questions:
- Which versions are still active?
- Which properties fail most often?
- Are implementers inventing the same missing concept?
- Which mappings are needed?

## P2 — DPP Ecosystem Operator
Needs an operational view of interoperability.

Key questions:
- Is ecosystem semantic health improving?
- Which organisations or sectors contribute most to fragmentation?
- Did a release create new conformance failures?

## P3 — Ontology Engineer
Needs low-level evidence.

Key questions:
- Which exact IRIs are involved?
- Which domains/ranges differ?
- Which mappings exist?
- Which SHACL constraints are failing?

## P4 — Product Data Engineer
Needs remediation guidance for an implementation.

Key questions:
- Why is our conformance decreasing?
- Which ontology version should we migrate to?
- Which custom properties need mappings?

## P5 — Researcher
Needs reproducible data and documented metrics.

Key questions:
- What is the metric definition?
- What is the ground truth?
- What detector performance was achieved?
