# External Context

This blueprint is inspired by the current DPP ecosystem in which CIRPASS-2 is working on DPP reference architecture, semantic interoperability, ontology networks, sector ontology mapping, pilots and validation tooling. TNO is publicly described as leading CIRPASS-2 architecture requirements/reference architecture work and contributing to the core DPP ontology and sectoral ontology mapping.

The DPP Vocabulary Hub / Semantic Treehouse is treated as an upstream semantic-governance/specification environment. The Observatory is deliberately positioned downstream: observing how versioned semantic specifications are used in implementations and aggregating runtime evidence.

## Implementation rule

Before integrating a specific CIRPASS-2 ontology, vocabulary, API, validation artifact or Vocabulary Hub endpoint:
1. identify the exact current artifact/version;
2. confirm license/usage terms;
3. pin provenance in repository metadata;
4. avoid hard-coding assumptions from screenshots or secondary descriptions.
