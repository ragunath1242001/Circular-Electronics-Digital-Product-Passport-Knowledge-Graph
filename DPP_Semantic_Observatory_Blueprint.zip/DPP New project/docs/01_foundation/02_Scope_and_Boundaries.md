# Scope and Boundaries

## In scope

- DPP semantic observability
- ontology/vocabulary usage analytics
- SHACL telemetry
- ontology version drift
- namespace and term analysis
- deprecated and unknown term detection
- configured semantic-fragmentation detection
- mapping registry and mapping coverage
- historical metrics
- evidence aggregation
- electronics + battery proof of concept
- synthetic DPP ecosystems
- knowledge graph integration
- REST APIs
- dashboard
- explainability
- reproducible evaluation

## Out of scope for MVP

- authoritative legal compliance
- blockchain
- identity wallet
- digital signatures
- VC/DID trust infrastructure
- EU production endpoints
- automatic changes to normative standards
- unrestricted automatic ontology alignment
- enterprise ERP/PIM/PLM connectors
- production SaaS billing/tenancy
- full lifecycle traceability

## Integration boundary with the existing DPP project

The existing system remains responsible for:
- DPP representation;
- product/material/manufacturer/component graph;
- RDF persistence;
- SPARQL;
- core UI;
- instance-level SHACL validation.

The Observatory extension owns:
- normalized semantic telemetry;
- ecosystem-level aggregation;
- time-aware metrics;
- drift detection;
- evidence creation;
- observability APIs;
- observability dashboard.

## Treehouse boundary

Semantic Treehouse / Vocabulary Hub is treated conceptually as a **source and governance environment for semantic specifications**, not something to replicate.

The Observatory consumes versioned semantic specifications and produces operational evidence that could be reviewed by maintainers.
