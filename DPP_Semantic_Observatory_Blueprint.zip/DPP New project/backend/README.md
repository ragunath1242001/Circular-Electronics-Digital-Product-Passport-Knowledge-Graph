# Backend Target Structure

```text
backend/
  app/
    api/
    config/
    db/
    ingestion/
    semantic_registry/
    validation/
    collectors/
    metrics/
    detectors/
    evidence/
    models/
  migrations/
  tests/
  pyproject.toml
```
