# Ontology Workspace

Expected layout:

```text
ontology/
  core/
    v1.0/
    v1.1/
    v2.0/
  domain/
    electronics/
    battery/
  shapes/
  mappings/
```

Do not copy external ontology content into this repository without checking licensing and provenance.

Where official/public DPP vocabularies are used, pin the source/version and document provenance.
