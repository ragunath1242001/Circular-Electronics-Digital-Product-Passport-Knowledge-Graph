# Data

`synthetic/` contains generated fictional DPP ecosystems.

`fixtures/` contains small deterministic examples for tests.

Never represent synthetic organisations as real companies.

Ground-truth fault manifests should be stored separately from generated DPP payloads so detectors cannot accidentally read the answer.
