# Master Project Blueprint

## 1. Product name

**DPP Semantic Observatory**

Subtitle: **Runtime Semantic Interoperability & Standard-Evolution Intelligence for Digital Product Passport Ecosystems**

## 2. Problem statement

Digital Product Passport ecosystems will be implemented by many manufacturers, sectors, software providers, and data platforms. Even when shared ontologies and validation specifications exist, interoperability can degrade because implementers:

- use different ontology versions;
- invent local terms;
- reuse different external vocabularies;
- apply mappings inconsistently;
- continue using deprecated concepts;
- serialize equivalent meaning differently;
- repeatedly fail the same semantic constraints;
- diverge across sectors.

Conventional validation is primarily instance-oriented: a DPP passes or fails a set of rules.

The Observatory adds an ecosystem-level question:

> What semantic patterns are occurring across the population of DPPs, how are those patterns changing over time, and where is semantic interoperability deteriorating?

## 3. Strategic position

```text
Regulation / DPP requirements
          |
          v
Semantic standardisation
(Treehouse / Vocabulary Hub / standards)
          |
          v
DPP implementations
          |
          v
Knowledge Graph + validation
          |
          v
=============================
DPP SEMANTIC OBSERVATORY
=============================
          |
          +--> usage signals
          +--> conformance telemetry
          +--> version drift
          +--> vocabulary fragmentation
          +--> mapping gaps
          +--> emerging concepts
          |
          v
Semantic evidence
          |
          v
Human review / standard evolution
```

## 4. Design principles

1. **Observe, don't rewrite.** The system never silently modifies source DPPs or ontologies.
2. **Evidence before AI.** Deterministic semantic evidence is the foundation. AI is optional enhancement.
3. **Explain every score.** Composite metrics must be decomposable into measurable components.
4. **Keep raw semantics and telemetry separate.** RDF graph for semantic knowledge; PostgreSQL for operational observations and time-series aggregates.
5. **Privacy by design.** Extract the minimum structural/semantic signals required for observability.
6. **Standards-aware, not standards-locked.** DPP is the primary domain, but observation primitives should be reusable.
7. **Synthetic ground truth first.** Evaluation starts from injected, known semantic faults.

## 5. MVP success definition

The MVP is complete when it can:

- ingest >=10,000 synthetic DPPs from >=20 fictional organisations;
- process at least two semantic domains: electronics and batteries;
- detect ontology/version usage;
- detect standard vs external vs custom vocabulary usage;
- run and retain SHACL validation telemetry;
- detect unknown/deprecated concepts;
- detect repeated semantic variants of the same configured concept;
- calculate documented metrics;
- show historical trends;
- identify evidence candidates for standard evolution;
- explain every alert/score with underlying observations;
- expose metrics/evidence through APIs and UI;
- reproduce evaluation from a clean Docker Compose environment.

## 6. Non-goals for MVP

- blockchain / distributed ledger;
- verifiable credentials / DIDs;
- autonomous ontology modification;
- production EU Registry integration;
- full legal-compliance determination;
- all DPP sectors;
- unrestricted LLM decision-making;
- production multi-tenant SaaS;
- raw enterprise ERP integration.

## 7. Reference architecture

```text
               +-------------------+
               | DPP Sources       |
               | RDF / JSON-LD     |
               +---------+---------+
                         |
                         v
               +-------------------+
               | Ingestion Gateway |
               +---------+---------+
                         |
                         v
               +-------------------+
               | Semantic Parser   |
               | + Normalizer      |
               +----+---------+----+
                    |         |
                    |         v
                    |  +-------------+
                    |  | SHACL Engine|
                    |  +------+------+
                    |         |
                    v         v
             +-----------------------+
             | Semantic Signal       |
             | Collector             |
             +-----------+-----------+
                         |
                         v
             +-----------------------+
             | Telemetry Event Store |
             | PostgreSQL            |
             +-----+-----------+-----+
                   |           |
                   v           v
          +-------------+ +-------------+
          | Metrics     | | Drift /     |
          | Engine      | | Evidence    |
          +------+------+ +------+------+
                 |               |
                 +-------+-------+
                         |
                         v
                 +---------------+
                 | Intelligence  |
                 | API           |
                 +------+--------+
                        |
                 +------+------+
                 |             |
                 v             v
          +-----------+   +-----------+
          | Dashboard |   | SPARQL/KG |
          +-----------+   +-----------+

      Semantic source-of-truth -> Apache Jena Fuseki
      Operational observations -> PostgreSQL
```

## 8. Key bounded contexts

### Semantic Registry
Owns ontology metadata, versions, namespaces, known terms, mappings, deprecations and SHACL profiles.

### Ingestion
Parses DPPs and assigns provenance, source organisation, domain and ingestion timestamp.

### Validation
Executes SHACL and translates results into normalized telemetry.

### Signal Collection
Extracts structural semantic observations from each DPP.

### Metrics
Aggregates observations into explainable KPIs.

### Drift Detection
Finds anomalies and semantic divergence.

### Evidence
Aggregates repeated observations into human-reviewable candidates for standard evolution.

### Dashboard/API
Exposes ecosystem state, trends, incidents and evidence.

## 9. Required implementation order

Do not start with the dashboard.

Implement in this sequence:

1. semantic model registry;
2. synthetic ecosystem generator;
3. DPP parser;
4. SHACL validation;
5. normalized telemetry schema;
6. signal collectors;
7. metric definitions + unit tests;
8. drift detectors;
9. evidence aggregation;
10. REST API;
11. dashboard;
12. evaluation;
13. optional AI explanations.

## 10. Definition of done

A feature is not done until it has:
- typed data contract;
- automated tests;
- observable errors;
- documentation;
- acceptance criterion;
- reproducible fixture;
- deterministic output where deterministic behavior is expected.
