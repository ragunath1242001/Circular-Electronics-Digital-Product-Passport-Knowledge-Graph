# Observability Domain

This folder documents/hosts domain logic if kept as a distinct package.

Subdomains:
- collectors
- metrics
- detectors
- evidence

Core logic should be testable without a running frontend.
