# DPP Semantic Observatory

**Runtime Semantic Interoperability & Standard-Evolution Intelligence for Digital Product Passport ecosystems**

## Project purpose

The DPP Semantic Observatory extends an existing semantic Digital Product Passport platform with an operational observability layer. The existing DPP system represents product passports using RDF/OWL/JSON-LD, validates them with SHACL, stores/query them in a knowledge graph, and exposes them through APIs/UI.

This project adds the ability to observe **how semantic standards are actually used across many DPP implementations**, detect where interoperability degrades, explain the causes, and generate structured evidence that can support future evolution of shared semantic models.

### Core idea

> Semantic standards define how DPP information **should** be represented.  
> The DPP Semantic Observatory measures how those standards are **actually** used, where semantic interoperability breaks down, and what recurring implementation evidence may indicate about future standard evolution.

## Scope boundary

This project is **not**:
- a clone of Semantic Treehouse;
- a generic DPP renderer;
- a blockchain DPP;
- an autonomous ontology-authoring agent;
- a full legal ESPR compliance engine.

It is an **observability and semantic-intelligence layer** for DPP ecosystems.

## Primary users

- ontology and vocabulary maintainers;
- DPP ecosystem operators;
- semantic/data-space architects;
- DPP service providers;
- product-data teams;
- standards and interoperability researchers.

## MVP

The MVP supports:
- electronics + battery domains;
- RDF/Turtle and JSON-LD ingestion;
- semantic model registry;
- SHACL validation telemetry;
- ontology/version detection;
- vocabulary reuse analysis;
- unknown/deprecated term detection;
- semantic fragmentation detection;
- mapping coverage;
- explainable metrics;
- historical trends;
- standard-evolution evidence candidates;
- REST API + observability dashboard;
- synthetic heterogeneous DPP ecosystem.

## Technology baseline

- Python
- FastAPI
- RDFLib
- pySHACL
- Apache Jena Fuseki
- PostgreSQL
- SPARQL
- RDF/OWL
- SHACL
- SKOS / OWL mappings
- PROV-O
- QUDT
- React / Next.js
- Docker Compose
- pytest

## Blueprint

Start with:

1. `docs/01_foundation/01_Project_Vision.md`
2. `docs/02_requirements/01_Functional_Requirements.md`
3. `docs/03_architecture/01_System_Architecture.md`
4. `docs/05_observability/01_Semantic_Signal_Catalogue.md`
5. `docs/05_observability/02_Metrics_Specification.md`
6. `docs/12_roadmap/01_Implementation_Roadmap.md`

The blueprint is intended to be implementation-ready for Codex or a software engineering team.
