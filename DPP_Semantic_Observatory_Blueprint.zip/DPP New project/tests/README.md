# Test Fixtures

Maintain:
- valid current-version DPP;
- valid legacy DPP;
- deprecated-term DPP;
- unknown-term DPP;
- custom-vocabulary DPP;
- datatype-error DPP;
- mapping-gap DPP;
- semantic-fragmentation scenario.
